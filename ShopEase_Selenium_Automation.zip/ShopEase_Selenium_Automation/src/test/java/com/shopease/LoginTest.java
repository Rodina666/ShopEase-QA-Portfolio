package com.shopease;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * ShopEase Selenium starter test.
 *
 * This is a portfolio/demo automation structure.
 * Replace BASE_URL and element locators with those of a real test environment
 * before executing the test.
 */
public class LoginTest {

    private WebDriver driver;

    private static final String BASE_URL = "https://example.test";
    private static final String VALID_EMAIL = "test@example.com";
    private static final String VALID_PASSWORD = "DemoPassword123";

    @BeforeEach
    void setUp() {
        driver = new ChromeDriver();
    }

    @Test
    void loginWithValidCredentials() {
        driver.get(BASE_URL + "/login");

        driver.findElement(By.id("email")).sendKeys(VALID_EMAIL);
        driver.findElement(By.id("password")).sendKeys(VALID_PASSWORD);
        driver.findElement(By.id("login")).click();

        assertEquals("Home", driver.getTitle());
    }

    @AfterEach
    void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}

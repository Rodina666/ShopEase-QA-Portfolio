# ShopEase Selenium Automation

## Project Type
Fictional / portfolio QA automation starter project.

## Purpose
This project demonstrates how a repeatable Selenium + Java smoke/regression test can be structured.

## Current Test
- Login with valid credentials

## Automation Candidates
- Login validation
- Product search
- Add to cart
- Checkout validation
- Logout / session behavior

## Before Execution
The project is intentionally not connected to a live ShopEase application.

Before running it:
1. Replace `BASE_URL` in `LoginTest.java`.
2. Replace the demo credentials.
3. Verify the element IDs (`email`, `password`, `login`) against the real test environment.
4. Run the test only against an environment you are authorized to test.

## Important
The portfolio case study presents the automation code as a starter structure. It must be connected to a real application before execution.
